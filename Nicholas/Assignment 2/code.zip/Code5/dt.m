function y = dt(x,d,parentlevel)
level=parentlevel+1;

tree=cell(1,2);
subtree=[];

A=tabulate(d);
P =cell2mat(A(1,2));
P =A{1,2};
N=cell2mat(A(2,2));

Mentropy=((-P/(P+N))*log2(P/(P+N))+(-N/(P+N))*log2(N/(P+N)));
if(isnan(Mentropy)==1)
    Mentropy=0;
end


%c=cell2mat(b);
%size(b)

p=0;
maxh=1;
maxgain=0;
maxK=[];
for h=1:size(x,2)
    K=[];
    b=tabulate(x(:,h));
   for i=1:size(b,1)
  
  y=ig((x(:,h)),d,i);

    K(i,:)=[ b{i,2} y];
    v=0;
 
    end
   K;
   h;
   Gain = Mentropy-sum(K(:,5));
   if(Gain>=maxgain)
       maxgain=Gain;
       maxh=h;
       maxK=K;
   end
   maxh ;
   maxgain;
   maxK;
end

winner=x(:,maxh);
b=tabulate(winner);
info=cell(size(b,1)+1,5);

info{size(b,1)+1,1}=maxh;
info{size(b,1)+1,2}='root';
info{size(b,1)+1,4}=level;
s=0;
for i=1:size(b,1)
    xnew=[];
    dnew=[];
    for j=1:size(winner,1)
     if( (winner{j}== b{i,1} ) )
          xnew=[xnew;[x(j,1:maxh-1) x(j,maxh+1:size(x,2))]];
          dnew=[dnew;d(j)];
     end
    end
    Z=tabulate(dnew);
    info{i,3}=xnew;
    info{i,4}=dnew;
if((size(Z,1))==1)
    info{i,1}=b{i,1};
    info{i,2}=Z{1,1};

else
    info{i,1}=b{i,1};
    s=s+1;
    info{i,5}=s;
    info{i,2}= strcat('split');
end
end



for i=1:size(info,1)-1
    if(info{i,2}=='split')
        info{i,1};
        isubtree=dt(info{i,3},info{i,4},level);
        subtree=[subtree,isubtree];
    end
end
  info{size(b,1)+1,3}=s;
 info
tree={info,subtree};
y=tree;




end