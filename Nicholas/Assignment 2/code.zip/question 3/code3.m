clc;
x = load ('wdbc_train.csv');
d=x(1:size(x,1),1);
x=x(1:size(x,1),2:size(x,2));
iterationsize=[1;5;11;15;21];

for i= 1:5
   
   Mdl = fitcknn(x,d,'NumNeighbors',iterationsize(i,1));
 
rloss = resubLoss(Mdl);
accuracy =1-rloss

 %predict(Mdl,[0 0])
end
