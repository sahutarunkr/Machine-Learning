clear;clc;
format short;
format compact;
x = load ('wdbc_train.data');
xval = load ('wdbc_test.data');
d=x(1:size(x,1),1);
x=x(1:size(x,1),2:size(x,2));
dval=xval(1:size(xval,1),1);
xval=xval(1:size(xval,1),2:size(xval,2));

no_Att=(size(x,2));
no_data=size(x,1);
no_Att_val=(size(xval,2));
no_data_val=size(xval,1);

maxAccuracy=0;
gamma_for_max=0;
fvalall=[];
accuracy=[];
sol=[];
H = diag([ones(1,no_Att) 0 zeros(1,no_data)]);
for pow=1
gamma =10^pow;
f= [zeros(no_Att+1,1); gamma*ones(no_data,1)];
q=(x.*(d*(-1*ones(1,no_Att))));
p=-1*d ;
m=-eye(no_data);
A = [ x.*(d*(-1*ones(1,no_Att))) -1*d -eye(no_data)];
b = -1*ones(no_data,1);
%A =zeros(1,83);
%//b = 0;clc
lb = [-inf*ones(no_Att+1,1); zeros(no_data,1)];%include for b
ub = [inf*ones(no_data+no_Att+1,1)];
[w,fval] = quadprog(H,f,A,b,[],[],lb,ub);

sol=[sol,w(1:no_Att+1)];
fvalall(pow+1,1)=fval;
y=[xval ones(no_data_val,1)]*w(1:no_Att_val+1,1);
for i=1:size(y,1)
    y(i,1)=y(i,1)/abs(y(i,1));
end

CP = classperf(grp2idx(dval), grp2idx(y));
accuracy(pow+1,1)=CP.CorrectRate;
if(accuracy(pow+1)>maxAccuracy)
    maxAccuracy=accuracy(pow+1);
    gamma_for_max=gamma;
end

end

sol
%fvalall=fvalall'
accuracy=accuracy'
