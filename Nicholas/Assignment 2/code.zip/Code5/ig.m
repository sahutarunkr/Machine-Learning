function y = ig(x,d,i)
if ~isvector(x)
    error('Input must be a vector')
end
A=tabulate(d);

P =A{1,2};
N=A{2,2};
Mentropy=((-P/(P+N))*log2(P/(P+N))+(-N/(P+N))*log2(N/(P+N)));
if(isnan(Mentropy)==1)
    Mentropy=0;
end
  p=0;
    n=0;
b=tabulate(x);
 for j=1:size(d,1)
        if( (x{j}== b{i,1} ) & (d{j,1}== A{1,1}))
           p=p+1;
        end
        if( (x{j}== b{i,1} ) & (d{j,1}== A{2,1}))
           n=n+1;
        end
            
 end
      
  entropy=((-p/(p+n))*log2(p/(p+n))+(-n/(p+n))*log2(n/(p+n)));
    if(isnan(entropy)==1)
    entropy=0;
    end
 v= ((p+n)/(P+N))*entropy;
 y=[p ,n ,entropy ,v];


end