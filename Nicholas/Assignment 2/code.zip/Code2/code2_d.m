clear;clc;
format short
format compact
x = load ('wdbc_train.data');
xval = load ('wdbc_test.data');
d=x(1:size(x,1),1);
x=x(1:size(x,1),2:size(x,2));
dval=xval(1:size(xval,1),1);
xval=xval(1:size(xval,1),2:size(xval,2));

no_Att=(size(x,2));
no_data=size(x,1);
no_Att_val=(size(xval,2));
no_data_val=size(xval,1);

fvalall=[];
accuracy=[];
accuracy_list=[];
solution_list=[];
sol=[];clc
sigma=.01;
xn = x.* (d*ones(1,no_Att));
k= xn*xn';
options =  optimset('Display','off');
maxaccuracy=0;


%H = diag([ones(1,no_Att) 0 zeros(1,no_data)]);
for pow=5
    for sig_pow=3
        sigma=.01*10^sig_pow;
gamma =.1*10^pow;


       
for i=1:no_data
    for j=1:no_data
        distance_dot =(x(i,:)-x(j,:))*(x(i,:)-x(j,:))';
        K=exp(-x(i,:)*x(i,:)')*exp(-x(j,:)*x(j,:)')*exp((x(i,:)*x(j,:)')/(sigma*sigma));
        
        H(i,j)=1*d(i)*d(j)*(exp((-1*distance_dot)/(2*sigma*sigma)));%*;%   -1 for maximizing the positive part
    end
end
f= [-1*ones(no_data,1)];

Aeq = d';
beq = 0;
%A =zeros(1,83);
%//b = 0;clci
lb = [ zeros(no_data,1)];
ub = [gamma*ones(no_data,1)];
[w,fval,exitflag,output,lambda] = quadprog(H,f,[],[],Aeq,beq,lb,ub,[],options);

%sol(sig_pow,pow,:)=[sol(sig_pow,pow,:),w(1:no_sol)]
%fvalall(sig_pow,pow,1)=fval;


for i=1:no_Att        
    (d.*x(1:no_data,i));
    slope(i,1)=w'*(d.*x(1:no_data,i));
end
n=0;b=0;
for i=1:size(w,1)
     if(w(i)>1.00e-0003)
         sum=0;
         for j=1:size(w,1)
             distance_dot =(x(i,:)-x(j,:))*(x(i,:)-x(j,:))';
            K=exp(-x(i,:)*x(i,:)'/2*(sigma*sigma))*exp(-x(j,:)*x(j,:)'/2*(sigma*sigma))*exp((x(i,:)*x(j,:)')/(sigma*sigma));
        
             sum=sum+(w(j)*d(j)*(exp((-1*distance_dot)/(2*sigma*sigma))));
         end
      bi= 1/d(i)-sum;
     b=b+bi;
     n=n+1;
    end
end
b=b/n;

for i=1:size(xval,1)
  sum=0;
         for j=1:size(w,1)
             distance_dot =(xval(i,:)-x(j,:))*(xval(i,:)-x(j,:))';
            K=exp(-x(i,:)*x(i,:)'/2*(sigma*sigma))*exp(-x(j,:)*x(j,:)'/2*(sigma*sigma))*exp((x(i,:)*x(j,:)')/(sigma*sigma));
        ;
             sum=sum+(w(j)*d(j)*(exp((-1*distance_dot)/(2*sigma*sigma))));
         end
         y(i,1)=sum+b;
end



for i=1:size(y,1)
    y(i,1)=y(i,1)/abs(y(i,1));
end

CP = classperf(grp2idx(dval), grp2idx(y));
accuracy=CP.CorrectRate;
accuracy_list=[accuracy_list, accuracy];


if(accuracy>maxaccuracy)
    maxaccuracy=accuracy;
    bestgamma=gamma;
    bestsigma=sigma;
end

  end
   gamma
   accuracy_list
   accuracy_list=[];
   
    solution_list=[];
end
bestgamma
bestsigma
