
format longEng
clear;clc;
zerolevel=0;

fileID = fopen('mush_test.data');
%C = textscan(fileID,'%q%q ','Delimiter',','); it flushes the the row
tline = fgets(fileID);
x=[];


while(tline~=-1)
  x=[x;strsplit(tline, ',')];
tline = fgets(fileID);

end
fclose(fileID);
d=x(1:size(x,1),1);
x=x(1:size(x,1),2:size(x,2));

fileID = fopen('mush_train.data');
%C = textscan(fileID,'%q%q ','Delimiter',','); it flushes the the row
tline = fgets(fileID);
xtest=[];

while(tline~=-1)
  xtest=[xtest;strsplit(tline, ',')];
tline = fgets(fileID);

end
fclose(fileID);
dtest=xtest(1:size(xtest,1),1);
xtest=xtest(1:size(xtest,1),2:size(xtest,2));
dpred=cell(size(dtest,1),1);
tree =dt(x,d,zerolevel);

for i=1:size(dtest,1)
    att=xtest(i,:);
    level=1;
    treetraversing=tree;
   splitno=1;
    while(isempty(dpred{i,1}))
       node=treetraversing{1,(-1+2*splitno)};
        pos=node{size(node,1),1};
    
   for j=1:(size(node,1)-1)
       
       
        if(att{1,pos}==node{j,1})
           node{j,2};
         if(~strcmp(node{j,2},'split'))
           dpred{i,1}=node{j,2};
          break;
         else
           att(:,pos)=[];
           treetraversing=treetraversing{1,2};
           splitno=node{j,5};
           break
       end
   end
   
   end
  
    end
end

CP = classperf(grp2idx(dtest), grp2idx(dpred));
accuracy=CP.CorrectRate


 